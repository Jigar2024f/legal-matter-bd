export default function Blog(params) {
    <div className=""></div>
};
