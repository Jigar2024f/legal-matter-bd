import image from "../images/home/team.png";

export const ourTeam = [
  {
    id: 1,
    name: "Md. Munzir Bakht",
    designation: "Full-Stack Developer",
    img: image,
  },
  {
    id: 2,
    name: "Sarah Rahman",
    designation: "UI/UX Designer",
    img: image,
  },
  {
    id: 3,
    name: "James Smith",
    designation: "Project Manager",
    img: image,
  },
  {
    id: 4,
    name: "Ayesha Khan",
    designation: "Frontend Developer",
    img: image,
  },
];
